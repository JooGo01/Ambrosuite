﻿function printInvoice() {
    window.print();
}